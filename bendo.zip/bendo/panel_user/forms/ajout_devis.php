<!-- traitement.php -->
<?php
require 'database.php';
require 'reference_aleat.php';

    if(!empty($_POST)) 
    {
        $ref_devis = checkInput($_POST['ref_devis']);
        $date_creat_devis = checkInput($_POST['date_creat_devis']);
        $date_expir_devis = checkInput($_POST['date_expir_devis']);
        $objet_devis = checkInput($_POST['objet_devis']);

        $db = Database::connect();
        $statement = $db->prepare("INSERT INTO ajout_devis (ref_devis, date_creat_devis, date_expir_devis, objet_devis)

         VALUES(?, ?, ?, ?)");

        $statement->execute(array($ref_devis, $date_creat_devis, $date_expir_devis, $objet_devis));

        Database::disconnect();
        
        // redirection de l'utilisateur sur la page article
        header('location: ../devis.php');      
    }

    function checkInput($data) 
        {
          $data = trim($data);
          $data = stripslashes($data);
          $data = htmlspecialchars($data);
          return $data;
        }

?>
<!-- fin traitement.php -->


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>form_devis</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" media="screen" href="css/form.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="main.js"></script>
</head>
<body>
    
    
</div>


<div class="container">
    <div class="row">
        <div class="col-lg-12">     
            <div class="tableaudebord">
                <div class="contact_container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <h2>  Édition Devis </h2>
                            <div class="nb_com" style="display:none">9</div>
                        </div>
                    </div> 
                </div>
                <div class='container'>
                    <div class='row'>
            <form class="form-horizontal" role="form" method="POST" action="ajout_devis.php" >
               <div class='row'>

              <div class="col-lg-12">
                 <div class="boutton">
                    <br> <br>                     
                    <div class="col-lg-1 col-md-1 col-xs-12">
                        <a href="../devis.php" style="color:white"><button class="btn btn-danger"  style="font-size: 1.3em"> Annuler <span class="glyphicon glyphicon-remove"></span> </button></a> 
                    </div>
                     <div class="col-lg-3 col-lg-offset-1 col-md-3 col-md-offset-1 col-xs-12">
                        <button name="submit" id="submit" type="submit" value="submit" class="btn btn-success" style="font-size: 1.3em"> Valider <span class="glyphicon glyphicon-chevron-right"></span></button>
                     </div>
                    <br> <br> <br>
                 </div>
              </div>
                                    
                                        <div class="col-lg-6">
                                            <!--<form class="form-horizontal" role="form">-->
                                           
                                            <div class="form-group">
                                                <label for="ref_devis" id="ref_devis" class="col-sm-2 control-label">Référence:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="ref_devis" id="ref_devis" value="FA-<?php echo genererChaineAleatoire(9); ?>" required>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="date_creat_devis" id="date_creat_devis" class="col-sm-2 control-label">Date de création:</label>
                                                <div class="col-sm-8">
                                                    <input type="date" class="form-control" name="date_creat_devis" id="date_creat_devis" required>
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label for="date_expir_devis" id="date_expir_devis" class="col-sm-2 control-label">Date d'expiration:</label>
                                                <div class="col-sm-8">
                                                    <input type="date" class="form-control" name="date_expir_devis" id="date_expir_devis" required>
                                                </div>
                                            </div>
                                            
                                            <div class="form-group">
                                                <label for="objet_devis" id="objet_devis" class="col-sm-2 control-label">Objet:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="objet_devis" id="objet_devis" placeholder="Saisir objet">
                                                </div>
                                            </div>
                                           
                                            <!--</form>-->
                                        </div>


                                        <div class="col-lg-6">
                                            <!--<form class="form-horizontal" role="form">-->
                                            
                                            <?Php
                                                $db = Database::connect();
                                                $req = $db->query("SELECT nom_client, ref_client FROM ajout_client");
                                            ?>

                                            <div class="form-group">

                                                <label for="" id="" class="col-sm-2 control-label">Client:</label>
                                                <div class="col-sm-8">
                                              <select name="list_client_devis" id="list_client_devis" style="width:250px; font-size:1.3em">
                                                 <option value="">-- Selectionner un client --</option>
                                              <?php
                                                 while($list_client= $req->fetch()){ 
                                              ?>
                                                <option value=""><?php echo $list_client['ref_client']. "&nbsp; &nbsp;" . $list_client['nom_client'] ?></option>
                                              <?php
                                                } 
                                              ?>
                                              </select>

                                                </div>  
                                            </div>                                            
                                            <!--</form>-->
                                        </div>
                                            <div class="row"> </div>
                                        </div>
                                        
 <!-- popup ajout ##################################################################"" -->
<div class="">
<div style="display:flex">
<h3 style="margin-left:5%; color:red">1) Saisir en mode libre</h3>
<h3 style="margin-left:35%; color:red">2) Insertion depuis produits et services</h3>
</div>
<div class="jumbotron" style="display:flex">
<div style="display:flex">

 <!-- popup article -->
<div>
  <!-- ############################# -->
  <a href="#"><button type="button" class="btn btn-info btn-lg" data-toggle="modal" >Article</button></a> 
</div>

 <!-- popup groupe article -->
<div class="">
  <!-- #################################### -->
  <a href="#"><button type="button" class="btn btn-info btn-lg" data-toggle="modal">Groupe article</button></a> 
  <!-- ######################### -->
</div>

 <!-- popup lot -->
<div class="">
  <!-- ##################################### -->
 <a href="#"><button type="button" class="btn btn-info btn-lg" data-toggle="modal">Lot&nbsp; &nbsp; &nbsp; &nbsp;</button></a> 
  <!-- ######################## -->
</div>
</div>
                 
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;
                                                              
<div style="display:flex">
<div>
  <!-- popup article -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal1">Article</button>
  <!-- ############################ -->
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog">
      <!-- ############################################ -->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Choisissez le client à ajouter</h4>
        </div>

        <?Php
            $db = Database::connect();
            $req = $db->query("SELECT ref_client, nom_client FROM ajout_client");
        ?>

        <?php
            while($articles= $req->fetch()){ 
        ?>
        <div class="modal-body">
          <a href="#" style="font-size:1.5em; text-decoration:none"><?php echo $articles['ref_client']. " - " .$articles['nom_client'] ?></h3></a>
        </div>
        <?php
        } 
        ?>

        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
        </div>
      </div>
    </div>
  </div>  
</div>

 <!-- popup groupe article -->
<div class="">
  <!-- #####################################"" -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal2">Groupe article</button>
  <!-- ################################## -->
  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
      <!-- #####################-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Choisissez le groupe d'article à ajouter</h4>
        </div>
        <div class="modal-body">
        <h3>groupe article1</h3>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
        </div>
      </div>
    </div>
  </div>
</div>

 <!-- popup lot -->
<div class="">
  <!-- ############################### -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal3">Lot&nbsp; &nbsp; &nbsp; &nbsp;</button>
  <!-- ############################ -->
  <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
      <!-- #########################-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Choisissez le lot à ajouter</h4>
        </div>
        <div class="modal-body">
        <h3>lot</h3>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>
</div>

                                <div class="body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                                <thead>
                                                    <tr>
                                                        <th>DESIGNATION</th>
                                                        <th>QTE</th>
                                                        <th>PRIX U</th>
                                                        <th>REMISE</th>
                                                        <th>TVA</th>
                                                        <th>TOTAL HT</th>                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        
                                                    </tr>
                                             
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

<!--##################################################################################################################"-->
<div class="container">

        <table class="table" style="width: 600px">
         
          <tbody>
    
            <tr class="success">
                    <td><b> Remise globale</b></td> <td> <span>0%</span></td>
            </tr>

            <tr class="Default">
                    <td><b>TOTAL HT</b></td> <td> <span>0,00</span></td>
            </tr>

            <tr class="info">
                    <td><b>TOTAL TTC</b></td><td><span>0,00</span></td>
            </tr>

            <tr class="Default">
                    <td><b>MARGE BRUTE HT</b></td> <td><span>0,00</span></td>
            </tr>

            <tr class="success">

                    <td><b>MARGE</b></td> <td><span>0,00 %</span></td>
            </tr>
          
          </tbody>
        </table>
      </div>

       <div>

            <div class="form-group">
                    <div class="col-sm-8">
                     <strong>Condition de réglément</strong>
                     <textarea type="text" rows="3" class="form-control" name="" id="" placeholder="">
                        Taux d'escompte : Pas d'escompte pour paiement anticipé. 
                        Taux de pénalité : En cas de retard de paiement, application d'intérêts de 3 fois le taux légal selon la loi n°2008-776 du 4 août 2008
                     </textarea>
                    </div>
                    <br><br>  <br> <br> 
                    <div class="col-sm-8">
                        <strong>Note devis</strong>
                        <textarea type="text" rows="3" class="form-control" name="" id="" placeholder="">
                            Pour vous notre meilleure offre
                        </textarea>
                         <br> <br> <hr> <br>
                    </div>
            </div>
         </div>

         </form>
         
         </div>
        </div>
       </div>
    </div>
    </div>
</div>

<?php
{
?>

<script>
function client()
{
    alert("<input type=button value='Fermer' onClick='window.close()'>");
}
</script>

<?php
}
?>


</body>
</html>