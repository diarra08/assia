<?php
// reference
     function genererChaineAleatoire($longueur = 10)
        {
            return substr(str_shuffle(str_repeat($x='0000000000123456789', ceil($longueur/strlen($x)) )),5,$longueur);
        }
?>