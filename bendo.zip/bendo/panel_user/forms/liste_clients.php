<?php require('database.php');?>
<?Php
 session_start();
 $db = Database::connect();
 $req = $db->query("SELECT * FROM ajout_client");
?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
  <script src="main.js"></script>
  
  <style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;

  <style>

body {font-family: Arial, Helvetica, sans-serif;}

* {box-sizing: border-box;}

​

input[type=text], select, textarea {

  width: 100%;

  padding: 12px;

  border: 1px solid #ccc;

  border-radius: 4px;

  box-sizing: border-box;

  margin-top: 6px;

  margin-bottom: 16px;

  resize: vertical;

}

​

input[type=submit] {

  background-color: #4CAF50;

  color: white;

  padding: 12px 20px;

  border: none;

  border-radius: 4px;

  cursor: pointer;

}

​

input[type=submit]:hover {

  background-color: #45a049;

}

​

.container {

  border-radius: 5px;

  background-color: #f2f2f2;

  padding: 20px;

}


/* recherche */

body {
  font-family: Arial;
}

* {
  box-sizing: border-box;
}

f
form.example button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}

</style>
</head>

<body style="background-color:gray">


<h1 style="text-align:center; font-weight: bold">LISTE DES CLIENTS</h1>
<br> <br>
<div class="container" style="width:40%; border:2px solid gray; background-color:white">
  <table>
  <?php
     while($liste= $req->fetch()){
  ?>

<input id="liste1" style="color:black; font-size: 1.4em; font-weight: bold; width:10Opx" type="text" value="<?php echo $liste['nom_client'] ?>" onclick="retour()">
<script>
function retour() {
  
  window.location.assign("ajout_devis.php")
  document.getElementById("liste1")
}
</script>

  </table>
  <?php
    } 
  ?>
</div>

</body>
</html>