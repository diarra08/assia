<!-- traitement.php -->
<?php
require 'database.php';

    if(!empty($_POST)) 
    {
        $lib_group_article = checkInput($_POST['lib_group_article']);

        $db = Database::connect();
        $statement = $db->prepare("INSERT INTO ajout_group_article (lib_group_article)

         VALUES(?)");

        $statement->execute(array($lib_group_article));

        Database::disconnect();
        
        // redirection de l'utilisateur sur la page article
        header('location: ../groupe_article.php');      
    }

    function checkInput($data) 
        {
          $data = trim($data);
          $data = stripslashes($data);
          $data = htmlspecialchars($data);
          return $data;
        }
?>
<!-- fin traitement.php -->


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>form groupe article</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link rel="stylesheet" type="text/css" media="screen" href="css/form.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="main.js"></script>
</head>
<body>
    
    
</div>


<div class="container">
    <div class="row">
        <div class="col-lg-12">     
            <div class="tableaudebord">
                <div class="contact_container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <h2>    Édition Groupe d'articles  </h2>
                            <div class="nb_com" style="display:none">9</div>
                        </div>
                    </div> 
                </div>
               <br> <br>
                <div class='container'>
                    <div class='row'>
                            <form class="form-horizontal" role="form" method="POST" action="ajout_groupe_article.php" >
                                
                                <div class='row'>
                                    
                                        <div class="col-lg-6">
                                            <!--<form class="form-horizontal" role="form">-->
                                            <div class="form-group">
                                                <label for="lib_group_article" id="lib_group_article" class="col-sm-2 control-label">Libellé:</label>
                                                <div class="col-sm-8">
                                                    <input type="text" class="form-control" name="lib_group_article" id="lib_group_article" placeholder="Nom du groupe d'articles">
                                                </div>
                                            </div>
                                           
                                            <!--</form>-->
                                        </div>


                                        <div class="col-lg-6">
                                            <!--<form class="form-horizontal" role="form">-->
                                            <div class="well">
                                                <span class="glyphicon glyphicon-list"></span>
                                                 Liste des articles et groupes d'articles 
                                                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                                   
                                                    <a href="#" style="color:white"><button type="button" class="btn btn-success"> Ajouter article  <span class="glyphicon glyphicon-plus"> </span></button> </a>                                           <!--</form>-->
                                        </div>

                                    
                                </div>

                                <div class="container">
                                   
                                </div>

                                <div class="body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                                <thead>
                                                    <tr>
                                                        <th>DESIGNATION</th>
                                                        <th>QUANTITE</th>
                                                        <th>PRIX</th>
                                                        <th>TVA</th>
                                                        <th>TOTAL HT</th>
                                                        <th>ACTION</th>                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                             
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

<!--##################################################################################################################"-->
<div class="container">

        <table class="table" style="width: 600px">
         
          <tbody>
    
            <tr class="success">
                    <td><b> Remise globale</b></td> <td> <span>0%</span></td>
            </tr>

            <tr class="Default">
                    <td><b>TOTAL HT</b></td> <td> <span>0,00</span></td>
            </tr>

            <tr class="info">
                    <td><b>TOTAL TTC</b></td><td><span>0,00</span></td>
            </tr>

            <tr class="Default">
                    <td><b>MARGE BRUTE HT</b></td> <td><span>0,00</span></td>
            </tr>

            <tr class="success">

                    <td><b>MARGE</b></td> <td><span>0,00 %</span></td>
            </tr>
          
          </tbody>
        </table>
      </div>

       <div>

            <div class="form-group">
                    <div class="col-sm-8">
                     <strong>Condition de réglément</strong>
                     <textarea type="text" rows="3" class="form-control" name="" id="" placeholder="">
                        Taux d'escompte : Pas d'escompte pour paiement anticipé. 
                        Taux de pénalité : En cas de retard de paiement, application d'intérêts de 3 fois le taux légal selon la loi n°2008-776 du 4 août 2008
                     </textarea>
                    </div>
                    <br><br>  <br> <br> 
                    <div class="col-sm-8">
                        <strong>Note devis</strong>
                        <textarea type="text" rows="3" class="form-control" name="" id="" placeholder="">
                            Pour vous notre meilleure offre
                        </textarea>
                    </div>
            </div>
         </div>

            <div class="row">
              <div class="col-lg-12">
                 <div class="boutton">
                    <br> <br>                     
                    <div class="col-lg-1 col-md-1 col-xs-12">
                        <a href="../groupe_article.php" style="color:white"><button class="btn btn-danger"  style="font-size: 1.3em"> Annuler <span class="glyphicon glyphicon-remove"></span> </button></a> 
                    </div>
                     <div class="col-lg-3 col-lg-offset-1 col-md-3 col-md-offset-1 col-xs-12">
                        <button name="submit" id="submit" type="submit" value="submit" class="btn btn-success" style="font-size: 1.3em"> Valider <span class="glyphicon glyphicon-chevron-right"></span></button>
                     </div>

                                          
                    <br> <br> <br>
                 </div>
              </div>
            </div>
         </form>
         </div>
        </div>
       </div>
    </div>
    </div>
</div>

</body>
</html>