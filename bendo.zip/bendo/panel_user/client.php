﻿<?php require('forms/database.php');?>
<?Php
 session_start();
 $db = Database::connect();
 $req = $db->query("SELECT nom_client, id_facture, montant_credit FROM ajout_client, ajout_facture, ajout_paiement_credit");
 
 //$req = $db->query("SELECT ajout_client.id_client, ajout_client.nom_client, ajout_facture.id_facture, ajout_paiement_credit.montant_credit
 //FROM ajout_client
 //INNER JOIN ajout_facture ON ajout_facture.id_facture = ajout_client.id_client
 //INNER JOIN ajout_paiement_credit ON ajout_paiement_credit.id_paiement_credit = ajout_facture.id_facture");

 //$req = $db->query("SELECT * FROM ajout_client INNER JOIN ajout_facture ON (ajout_client.id_client = ajout_facture.id_facture) AND (SELECT montant_credit FROM ajout_paiement_credit));");
 ?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>client</title>
    <!-- Favicon-->

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- JQuery DataTable Css -->
    <link href="plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-red">
    <!-- Page Loader -->

    <header>
       <?php
       include('header_user.php');
       ?>
    </header>

<!--############################################################################################################"-->
    <section class="content">
        <div class="container-fluid">
           
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                                    Liste des Clients
                            </h2>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th>CLIENT</th>
                                            <th>FACTURE EN ATTENTE</th>
                                            <th>SOLDE COURANT</th>
                                            <th>ACTION</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                         while($client= $req->fetch()){ 
                                         ?>
                                        <tr>
                                            <td><?php echo $client['nom_client'] ?></td>
                                            <td><?php echo $client['id_facture'] ?></td>
                                            <td><?php echo $client['montant_credit'] ?></td>
                                            <td style="display:inline-flex">
                                            <button class="btn btn-info">Voir</button>
                                            <button class="btn btn-success">Modifier</button>
                                            <a href="traitement/sup_client.php?id=<?php echo $client['nom_client']; ?>"><button class="btn btn-danger">Supprimer</button></a>
                                            <a href="forms/ajout_facture.php"><button class="btn btn-default" style="background-color:gray">Créer Facture</button></a>
                                            <a href="forms/ajout_devis.php"><button class="btn btn-primary">Céer Devis</button></a>
                                            
                                            </td>
                                        </tr>
                                    </tbody>
                                    <?php
                                     } 
                                    ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Examples -->
            <!-- Exportable Table -->

                 <div class="container">
                    <a href="forms/ajout_client.php"><button type="button" class="btn glyphicon glyphicon-plus" style="font-size:1em; color:white; background-color:green"> Creer </button> </a>
                 </div>
                 <br> <br> <br>
            <!-- #END# Exportable Table -->
        </div>
    </section>

     <!-- Les events -->
    <script>
       function voir(){
         window.location.assign("#")
        }

        function modifier(){
         window.location.assign("#")
        }

        function supprimer(){
         window.location.assign("#")
        }

        function creatFacture(){
         window.location.assign("forms/ajout_facture.php")
        }

        function creatDevis(){
         window.location.assign("forms/ajout_devis.php")
        }
    </script>

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>

</html>