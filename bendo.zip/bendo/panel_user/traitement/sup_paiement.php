<?php
session_start();

    require '../forms/database.php';
 
    if(!empty($_GET['id'])) 
    {
        $id = checkInput($_GET['id']);
    }
       $db = Database::connect();
       $items = $db->prepare("SELECT * FROM ajout_client WHERE nom_client = ?");
       $items -> execute(array($id));
       $affiche = $items -> fetch();
       
        
        $statement = $db->prepare("DELETE FROM ajout_client WHERE nom_client = ?");
        $statement->execute(array($affiche['nom_client']));
        $statement = $db->prepare("DELETE FROM ajout_client WHERE nom_client = ?");
        $statement->execute(array($id));
        Database::disconnect();
        header("Location: ../paiement.php"); 

        
    function checkInput($data) 
    {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
  
?>